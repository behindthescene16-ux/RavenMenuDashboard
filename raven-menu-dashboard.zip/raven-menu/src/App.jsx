import { useState } from "react";

const BRAND = {
  brown: "#3B2314",
  gold: "#C9A84C",
  cream: "#FAF6F0",
  text: "#2C1A0E",
  muted: "#888",
  border: "#E8DDD0",
};

const categoryColors = {
  "SWEET OATS":     { bg: "#F5EDD8", text: "#8B5E1A" },
  "SAVORY OATS":    { bg: "#EAF0EA", text: "#2A4A2A" },
  "WARM BOWL":      { bg: "#FEF3E8", text: "#7A3A10" },
  "WARM SOUP":      { bg: "#FEF3E8", text: "#7A3A10" },
  "BROTH BOWL":     { bg: "#E8F5F0", text: "#1A5A40" },
  "CONGEE":         { bg: "#FEF3E8", text: "#7A3A10" },
  "SCRAMBLE":       { bg: "#FDE8F0", text: "#7A1040" },
  "SAVORY PLATE":   { bg: "#EAF0EA", text: "#2A4A2A" },
  "HASH":           { bg: "#F5EDD8", text: "#8B5E1A" },
  "TOAST":          { bg: "#F5EDD8", text: "#8B5E1A" },
  "AVOCADO TOAST":  { bg: "#EAF0EA", text: "#2A4A2A" },
  "SAVORY TOAST":   { bg: "#EAF0EA", text: "#2A4A2A" },
  "FRUIT BOWL":     { bg: "#FDE8F0", text: "#7A1040" },
  "BOWL":           { bg: "#EEF3FB", text: "#2A3A6A" },
  "OVERNIGHT OATS": { bg: "#F0EAF8", text: "#4A1A7A" },
  "MORNING RITUAL": { bg: "#FDE8F0", text: "#7A1040" },
  // Snack categories
  "HUMMUS":         { bg: "#F5EDD8", text: "#8B5E1A" },
  "BEAN DIP":       { bg: "#EAF0EA", text: "#2A4A2A" },
  "GUACAMOLE":      { bg: "#E8F5F0", text: "#1A5A40" },
  "SALSA":          { bg: "#FEF3E8", text: "#7A3A10" },
  "MEZZE":          { bg: "#FDE8F0", text: "#7A1040" },
  "MARINATED":      { bg: "#EEF3FB", text: "#2A3A6A" },
  "CRUDITÉ":        { bg: "#E8F5F0", text: "#1A5A40" },
  "CHIPS":          { bg: "#F5EDD8", text: "#8B5E1A" },
  // Smoothie categories
  "BERRY BLEND":    { bg: "#F0E8F8", text: "#5A1A7A" },
  "GOLDEN":         { bg: "#F5EDD8", text: "#8B5E1A" },
  "CHOCOLATE":      { bg: "#EDE0D8", text: "#3B2314" },
  "GREEN":          { bg: "#EAF0EA", text: "#2A4A2A" },
  "TROPICAL":       { bg: "#FDE8F0", text: "#7A1040" },
  "ADAPTOGEN":      { bg: "#E8F5F0", text: "#1A5A40" },
  "PROBIOTIC":      { bg: "#FEF3E8", text: "#7A3A10" },
};

// ── MIDDAY PROTEIN SMOOTHIES ──────────────────────────────────────
const smoothieCards = [
  // BERRY BLENDS
  { id: "sm1", category: "BERRY BLEND", emoji: "🫐", title: "The Blackberry Reishi", desc: "Blackberries, pea protein, reishi mushroom powder, oat milk, pomegranate juice, ACV, cinnamon, walnut oil — deep purple, anti-inflammatory", badges: ["⭐ Superfood", "Reishi", "Pea Protein", "Vegan", "GF"] },
  { id: "sm2", category: "BERRY BLEND", emoji: "🍓", title: "Strawberry Rose Adaptogen", desc: "Strawberries, pea protein, ashwagandha, maca, oat milk, rose water, lime juice, cinnamon, honey — blush pink, stress + hormone balance", badges: ["⭐ Superfood", "Ashwagandha", "Maca", "Pea Protein", "Vegan"] },
  { id: "sm3", category: "BERRY BLEND", emoji: "🍒", title: "Cranberry Chaga Glow", desc: "Cranberries, pea protein, chaga powder, coconut milk, pomegranate juice, orange zest, ACV, ginger — tart, antioxidant-rich, immune forward", badges: ["⭐ Superfood", "Chaga", "Pea Protein", "Vegan", "GF"] },
  // GOLDEN / TURMERIC
  { id: "sm4", category: "GOLDEN", emoji: "✨", title: "Golden Sun Shake", desc: "Oat milk, pea protein, turmeric, ginger, cinnamon, black pepper, maca, coconut cream, orange juice, honey — warm gold, anti-inflammatory core", badges: ["⭐ Superfood", "Turmeric", "Maca", "Pea Protein", "Vegan"] },
  { id: "sm5", category: "GOLDEN", emoji: "🍊", title: "Citrus Ashwagandha Elixir", desc: "Fresh orange juice, pea protein, ashwagandha, turmeric, ginger, oat milk, ACV, cinnamon, honey — bright, stress-adapting, hormone support", badges: ["⭐ Superfood", "Ashwagandha", "Turmeric", "Pea Protein", "Vegan"] },
  { id: "sm6", category: "GOLDEN", emoji: "🌕", title: "The Erewhon Gold", desc: "Oat milk, pea protein, maca, turmeric, lion's mane, coconut cream, cinnamon, vanilla, walnut oil, pomegranate seeds — layered functional gold shake", badges: ["⭐ Superfood", "Lion's Mane", "Maca", "Pea Protein", "Vegan"] },
  // CHOCOLATE / CACAO
  { id: "sm7", category: "CHOCOLATE", emoji: "🍫", title: "Ceremonial Cacao Reishi Shake", desc: "Raw cacao powder, pea protein, reishi, oat milk, coconut cream, cinnamon, maca, walnut oil, honey — rich, grounding, mood-lifting", badges: ["⭐ Superfood", "Reishi", "Cacao", "Pea Protein", "Vegan"] },
  { id: "sm8", category: "CHOCOLATE", emoji: "🌑", title: "Chaga Dark Chocolate Protein", desc: "Raw cacao, pea protein, chaga powder, oat milk, coconut milk, cinnamon, ginger, pomegranate juice, honey — deep chocolate, immune + gut support", badges: ["⭐ Superfood", "Chaga", "Cacao", "Pea Protein", "Vegan"] },
  // GREEN
  { id: "sm9", category: "GREEN", emoji: "🌿", title: "Lion's Mane Green Clarity", desc: "Oat milk, pea protein, lion's mane powder, watercress (small), cucumber, fresh ginger, lime, ACV, cinnamon, honey — clean green, brain + focus", badges: ["⭐ Superfood", "Lion's Mane", "Pea Protein", "Vegan", "GF"] },
  { id: "sm10", category: "GREEN", emoji: "🥒", title: "Cucumber Ginger Detox Shake", desc: "Cucumber, pea protein, fresh ginger, lime, ACV, oat milk, turmeric, cinnamon, walnut oil — clean, alkaline, gut-support, light and refreshing", badges: ["⭐ Superfood", "Turmeric", "Pea Protein", "Vegan", "GF"] },
  // TROPICAL
  { id: "sm11", category: "TROPICAL", emoji: "🍈", title: "Papaya Maca Sunrise", desc: "Fresh papaya, pea protein, maca, coconut milk, lime juice, ginger, turmeric, cinnamon, honey — bright tropical, enzyme-rich, digestive support", badges: ["⭐ Superfood", "Maca", "Pea Protein", "Vegan", "GF"] },
  { id: "sm12", category: "TROPICAL", emoji: "🍍", title: "Pineapple Ashwagandha Refresh", desc: "Pineapple, pea protein, ashwagandha, coconut milk, lime, ginger, ACV, turmeric, honey — anti-inflammatory enzyme base, cortisol support", badges: ["⭐ Superfood", "Ashwagandha", "Pea Protein", "Vegan", "GF"] },
  // ADAPTOGEN ELIXIRS
  { id: "sm13", category: "ADAPTOGEN", emoji: "🍄", title: "The Mushroom Stack", desc: "Oat milk, pea protein, reishi + lion's mane + chaga blend, raw cacao, cinnamon, walnut oil, honey — full adaptogen stack, immune + brain + gut", badges: ["⭐ Superfood", "Reishi", "Lion's Mane", "Chaga", "Pea Protein", "Vegan"] },
  { id: "sm14", category: "ADAPTOGEN", emoji: "🌙", title: "Ashwagandha Moon Milk Shake", desc: "Oat milk, coconut cream, pea protein, ashwagandha, maca, cinnamon, walnut oil, honey, black pepper — calming, hormone-balancing, evening wind-down", badges: ["⭐ Superfood", "Ashwagandha", "Maca", "Pea Protein", "Vegan"] },
  // PROBIOTIC
  { id: "sm15", category: "PROBIOTIC", emoji: "🍊", title: "ACV Citrus Gut Shake", desc: "Orange juice, pea protein, ACV, ginger, turmeric, cinnamon, oat milk, pomegranate juice, honey — tangy, gut-healing, microbiome support", badges: ["⭐ Superfood", "ACV", "Pea Protein", "Vegan", "GF", "Probiotic"] },
  { id: "sm16", category: "PROBIOTIC", emoji: "🫐", title: "Berry ACV Glow Shake", desc: "Blackberries, strawberries, pea protein, ACV, pomegranate juice, ginger, lime, oat milk, cinnamon — bright berry, probiotic-forward, skin + gut glow", badges: ["⭐ Superfood", "ACV", "Pea Protein", "Vegan", "GF", "Probiotic"] },
];

// ── SNACKS: Dips, Salsas & Marinated Cups ────────────────────────
const snackCards = [
  // HUMMUS
  { id: "sn1", category: "HUMMUS", emoji: "⚫", title: "Black Eyed Pea Hummus", desc: "Black eyed peas, lemon, cumin, walnut oil swoosh, pomegranate jewels, fresh parsley — served with crudité or house tortilla chips", badges: ["⭐ Superfood", "15 min", "Vegan", "GF"] },
  { id: "sn2", category: "HUMMUS", emoji: "🫘", title: "Classic Chickpea Hummus", desc: "Chickpeas, lemon, cumin, turmeric, walnut oil drizzle, paprika dust, fresh herbs — served with crudité or house tortilla chips", badges: ["⭐ Superfood", "15 min", "Vegan", "GF"] },
  { id: "sn3", category: "HUMMUS", emoji: "🔴", title: "Roasted Red Pepper Hummus", desc: "Chickpeas, roasted red bell pepper, lemon, cumin, smoked paprika, walnut oil swirl — served with crudité or house tortilla chips", badges: ["⭐ Superfood", "20 min", "Vegan", "GF"] },

  // BEAN DIPS
  { id: "sn4", category: "BEAN DIP", emoji: "🌿", title: "White Bean & Rosemary Dip", desc: "White beans, fresh rosemary, lemon, walnut oil, nutritional yeast — smooth whipped dip served with crudité or house tortilla chips", badges: ["⭐ Superfood", "15 min", "Vegan", "GF"] },

  // GUACAMOLE
  { id: "sn5", category: "GUACAMOLE", emoji: "🥑", title: "House Guacamole", desc: "Avocado, lime, cilantro, cherry tomato, jalapeño (optional), cumin, ACV — served with crudité or house tortilla chips", badges: ["⭐ Superfood", "10 min", "Vegan", "GF"] },

  // SALSAS
  { id: "sn6", category: "SALSA", emoji: "🌽", title: "Corn & Fava Bean Summer Salsa", desc: "Roasted corn, fava beans, roasted red + yellow bell pepper, cherry tomato, lime juice, ACV, cilantro, cumin — served with house tortilla chips or crudité", badges: ["⭐ Superfood", "20 min", "Vegan", "GF"] },
  { id: "sn7", category: "SALSA", emoji: "🍅", title: "Roasted Tomato & Bell Pepper Salsa", desc: "Slow-roasted cherry tomato, red bell pepper, lime, ACV, fresh cilantro, cumin, smoked paprika — served warm or room temp with chips or crudité", badges: ["⭐ Superfood", "25 min", "Vegan", "GF"] },

  // MEDITERRANEAN DIPS
  { id: "sn8", category: "MEZZE", emoji: "🌶️", title: "Muhammara", desc: "Roasted red bell pepper, walnuts, pomegranate molasses, lemon, cumin, smoked paprika, walnut oil — served with crudité or GF pita", badges: ["⭐ Superfood", "20 min", "Vegan", "GF"] },
  { id: "sn9", category: "MEZZE", emoji: "🍆", title: "Roasted Eggplant Dip", desc: "Fire-roasted eggplant, lemon, cumin, fresh herbs, walnut oil swirl, pomegranate jewels — served with crudité or house tortilla chips", badges: ["⭐ Superfood", "30 min", "Vegan", "GF"] },
  { id: "sn10", category: "MEZZE", emoji: "🍅", title: "Mediterranean Tomato Dip", desc: "Slow-roasted tomato, roasted red pepper, fresh basil, lemon zest, walnut oil, cumin, smoked paprika — served warm with crudité or chips", badges: ["⭐ Superfood", "25 min", "Vegan", "GF"] },

  // MARINATED CUPS
  { id: "sn11", category: "MARINATED", emoji: "🥒", title: "Asian-Style Cucumber Salad Cups", desc: "Thin-sliced cucumber, rice vinegar, ginger, lime, coconut aminos, sesame oil (small), fresh cilantro, pomegranate seeds — served chilled in ceramic cups", badges: ["⭐ Superfood", "10 min", "Vegan", "GF", "Chilled"] },
  { id: "sn12", category: "MARINATED", emoji: "🥕", title: "Marinated Carrot Ribbon Salad Cups", desc: "Shaved carrot ribbons, ACV, ginger, lime, turmeric, walnut oil, fresh cilantro, pomegranate jewels — served chilled in ceramic cups", badges: ["⭐ Superfood", "15 min", "Vegan", "GF", "Chilled"] },

  // SERVED WITH
  { id: "sn13", category: "CRUDITÉ", emoji: "🥕", title: "Anti-Inflammatory Crudité Board", desc: "Rainbow carrots, cucumber spears, celery, fennel wedges, bell pepper strips, radish, cherry tomato — choose your dip pairing", badges: ["⭐ Superfood", "10 min", "Vegan", "GF", "Raw"] },
  { id: "sn14", category: "CHIPS", emoji: "🌽", title: "House Tortilla Chips", desc: "Thin-sliced corn tortillas, fried or baked, lime salt finish — served warm — choose your dip pairing", badges: ["10 min", "Vegan", "GF"] },
];

// ── MONDAY: Warm Oat Bowls ─────────────────────────────────────────
const mondayCards = [
  { id: "m1", category: "SWEET OATS", emoji: "🍒", title: "Cranberry Compote Steel Cut Oats", desc: "Steel cut oats, oat milk, warm cranberry compote, orange zest, cinnamon, maple syrup, heavy cream whip, ground flax", badges: ["⭐ Superfood", "25 min", "Warm"] },
  { id: "m2", category: "SWEET OATS", emoji: "🫐", title: "Blackberry Ginger Compote Oats", desc: "Steel cut oats, oat milk, blackberry-ginger compote, lime juice, honey, heavy cream whip, fresh blackberries, chia seeds", badges: ["⭐ Superfood", "25 min", "Warm"] },
  { id: "m3", category: "SWEET OATS", emoji: "🍓", title: "Strawberry Compote Oats", desc: "Steel cut oats, oat milk, strawberry compote, cinnamon, cardamom, ACV, fresh strawberries, orange segments, heavy cream whip, sesame seeds", badges: ["⭐ Superfood", "25 min", "Warm"] },
  { id: "m4", category: "SAVORY OATS", emoji: "🍄", title: "Savory Miso Mushroom Oats", desc: "Steel cut oats, mushroom broth, shiitake + oyster + maitake in ghee, white miso, fresh thyme, turmeric, ginger, walnut oil, sesame seeds", badges: ["⭐ Superfood", "30 min", "GF"] },
  { id: "m5", category: "SAVORY OATS", emoji: "🥬", title: "Stewed Kale & Mushroom Porridge", desc: "Steel cut oats, chanterelle broth, lacinato kale (well braised), white mushroom, chanterelle, turmeric, ginger, cumin, walnut oil, nutritional yeast, sauerkraut", badges: ["⭐ Superfood", "35 min", "GF"] },
  { id: "m6", category: "WARM BOWL", emoji: "🍊", title: "Cranberry Orange Compote Bowl", desc: "Warm cranberry-ginger compote, orange segments, oat base, ACV drizzle, cotija snow, walnut oil finish", badges: ["⭐ Superfood", "20 min", "Warm"] },
];

// ── TUESDAY: Warm Broth Bowls ──────────────────────────────────────
const tuesdayCards = [
  { id: "t1", category: "CONGEE", emoji: "🍚", title: "Shiitake Congee", desc: "Rice porridge, green lentil broth, ginger + turmeric tonic, crispy shiitake crown, microgreens, poured tableside", badges: ["⭐ Superfood", "35 min", "GF"] },
  { id: "t2", category: "WARM SOUP", emoji: "🫘", title: "Turmeric Lentil Breakfast Soup", desc: "Green lentils, turmeric, ginger, fennel, cumin — small ceramic bowl, fennel frond float, lime oil drizzle", badges: ["⭐ Superfood", "30 min", "GF"] },
  { id: "t3", category: "BROTH BOWL", emoji: "🍵", title: "Mushroom Broth Wake-Up Cup", desc: "Shiitake + maitake + ginger + turmeric adaptogenic broth, ceramic handleless cup, herb sprig", badges: ["⭐ Superfood", "20 min", "GF"] },
  { id: "t4", category: "WARM BOWL", emoji: "🌿", title: "Green Lentil Ginger Broth Bowl", desc: "Green lentils simmered in ginger-turmeric broth, fennel bulb, peas, lime oil, fresh cilantro, walnut oil drizzle", badges: ["⭐ Superfood", "30 min", "GF", "Vegan"] },
  { id: "t5", category: "BROTH BOWL", emoji: "🍄", title: "Maitake Dashi Morning Bowl", desc: "Maitake + chanterelle in light dashi-style mushroom broth, coconut aminos, ginger, sesame oil (small), scallion tops, microgreens", badges: ["⭐ Superfood", "25 min", "GF"] },
  { id: "t6", category: "WARM BOWL", emoji: "🟡", title: "Golden Milk Oat Broth Bowl", desc: "Oats cooked in turmeric-ginger-cinnamon golden milk broth, oat milk, pomegranate seeds, walnut oil, black pepper", badges: ["⭐ Superfood", "20 min", "Vegan"] },
];

// ── WEDNESDAY: Hot Breakfast Scrambles ────────────────────────────
const wednesdayCards = [
  { id: "w1", category: "SCRAMBLE", emoji: "🍄", title: "Mushroom & Herb Tofu Scramble", desc: "Firm tofu crumble, shiitake + oyster mushrooms, turmeric, nutritional yeast, fresh thyme, walnut oil, microgreens", badges: ["⭐ Superfood", "20 min", "Vegan", "GF"] },
  { id: "w2", category: "SAVORY PLATE", emoji: "🫑", title: "Portabella Breakfast Plate", desc: "Grilled portabella cap, crispy oyster mushroom slab, avocado fan, cherry tomato, golden turmeric pour-over", badges: ["⭐ Superfood", "20 min", "Vegan", "GF"] },
  { id: "w3", category: "SCRAMBLE", emoji: "🌿", title: "Chanterelle & Fennel Scramble", desc: "Sautéed chanterelle + fennel in ghee, turmeric, lemon zest, nutritional yeast, fresh herbs, cotija crumble", badges: ["⭐ Superfood", "20 min", "GF"] },
  { id: "w4", category: "HASH", emoji: "🥔", title: "Sweet Potato Mushroom Hash", desc: "Sweet potato, oyster + maitake mushrooms, bell pepper, ghee, cumin, paprika, turmeric, fresh cilantro, lime wedge", badges: ["⭐ Superfood", "30 min", "Vegan", "GF"] },
  { id: "w5", category: "SCRAMBLE", emoji: "🍅", title: "Tomato Turmeric Chickpea Scramble", desc: "Chickpea crumble, cherry tomato, bell pepper, turmeric, cumin, ginger, fresh basil, walnut oil drizzle", badges: ["⭐ Superfood", "20 min", "Vegan", "GF"] },
  { id: "w6", category: "SAVORY PLATE", emoji: "🥑", title: "Avocado & Roasted Tomato Plate", desc: "Fanned avocado, slow-roasted cherry tomato, watercress, lime-turmeric drizzle, cotija snow, pomegranate jewels", badges: ["⭐ Superfood", "25 min", "Vegan", "GF"] },
];

// ── THURSDAY: Breakfast Toasts ─────────────────────────────────────
const thursdayCards = [
  { id: "th1", category: "SAVORY TOAST", emoji: "🍄", title: "Maitake & Chanterelle Toast", desc: "GF sourdough, sautéed maitake + chanterelle in ghee + thyme, walnut oil, nutritional yeast, lemon zest, microgreens", badges: ["⭐ Superfood", "20 min", "GF"] },
  { id: "th2", category: "AVOCADO TOAST", emoji: "🥑", title: "California Avocado Toast", desc: "GF sourdough, smashed avocado + lime + turmeric, cherry tomato, watercress, pomegranate jewels, cotija crumble", badges: ["⭐ Superfood", "10 min", "GF"] },
  { id: "th3", category: "AVOCADO TOAST", emoji: "🍄", title: "Chanterelle Avocado Toast", desc: "Avocado canvas, sautéed chanterelle crown piled high, fennel frond, cherry tomato, capers, nutritional yeast", badges: ["⭐ Superfood", "20 min", "GF"] },
  { id: "th4", category: "SAVORY TOAST", emoji: "🥑", title: "Chanterelle & Avocado Open-Face", desc: "GF toast, smashed avocado, sautéed chanterelle crown, cherry tomato, watercress, lime zest, nutritional yeast", badges: ["⭐ Superfood", "15 min", "GF"] },
  { id: "th5", category: "TOAST", emoji: "🫘", title: "Mashed Chickpea & Chanterelle Toast", desc: "Chunky chickpea + rosemary smash, chanterelle sauté in ghee + thyme, walnut oil drizzle, nutritional yeast", badges: ["⭐ Superfood", "22 min", "GF"] },
  { id: "th6", category: "TOAST", emoji: "⚫", title: "BEP Hummus & Maitake Toast", desc: "Black eyed pea hummus swoosh, roasted maitake crown, beet sprouts, pomegranate jewels, walnut oil gloss", badges: ["⭐ Superfood", "25 min", "GF"] },
];

// ── FRIDAY: Breakfast Fruit Bowls ──────────────────────────────────
const fridayCards = [
  { id: "f1", category: "BOWL", emoji: "🫐", title: "Açaí + Berry Crown Bowl", desc: "Thick açaí + oat milk base, pea protein, fanned strawberries, pomegranate jewels, blackberry crown, ACV drizzle, cinnamon", badges: ["⭐ Superfood", "15 min", "Vegan"] },
  { id: "f2", category: "FRUIT BOWL", emoji: "🍈", title: "Golden Papaya Boat", desc: "Halved papaya vessel, blackberries, orange segments, ginger-lime drizzle, whipped coconut yogurt, edible flowers", badges: ["⭐ Superfood", "10 min", "GF"] },
  { id: "f3", category: "FRUIT BOWL", emoji: "🌅", title: "Pomegranate Chia Sunrise", desc: "Sunrise gradient: orange chia base fading to deep açaí, pomegranate seeds on top, green tea on the side", badges: ["10 min", "Vegan", "Light"] },
  { id: "f4", category: "FRUIT BOWL", emoji: "🍓", title: "Strawberry Blackberry Crown Bowl", desc: "Fresh strawberries + blackberries, acai base, orange segments, ginger-lime drizzle, walnut oil gloss, cinnamon dust", badges: ["⭐ Superfood", "10 min", "Vegan", "GF"] },
  { id: "f5", category: "FRUIT BOWL", emoji: "🍊", title: "Citrus & Pomegranate Sunrise Bowl", desc: "Orange + lime segments, pomegranate jewels, papaya, cranberry compote drizzle, ACV, fresh mint, cinnamon", badges: ["⭐ Superfood", "10 min", "Vegan", "GF"] },
  { id: "f6", category: "FRUIT BOWL", emoji: "🫐", title: "Triple Berry Açaí Bowl", desc: "Açaí base, strawberry + blackberry + cranberry compote layers, pea protein, walnut oil drizzle, flax seeds", badges: ["⭐ Superfood", "15 min", "Vegan", "GF"] },
];

// ── WEEKEND: DIY Prep-Ahead ────────────────────────────────────────
const weekendCards = [
  { id: "sa1", category: "OVERNIGHT OATS", emoji: "✨", title: "Golden Overnight Oats", desc: "Turmeric + ginger + cinnamon golden milk oats, pea protein, blackberry compote swirl, pomegranate seeds, mason jar", badges: ["⭐ Superfood", "Prep-Ahead", "Vegan"] },
  { id: "sa2", category: "OVERNIGHT OATS", emoji: "🍓", title: "Strawberry Rose Overnight Parfait", desc: "Pea protein oats soaked overnight, rose-cut strawberry crown, layered blackberry compote, rose petals", badges: ["⭐ Superfood", "Prep-Ahead", "GF"] },
  { id: "sa3", category: "OVERNIGHT OATS", emoji: "🫐", title: "Blackberry Ginger Overnight Oats", desc: "Steel cut oats, oat milk, blackberry-ginger compote layered, chia seeds, honey, prep-ahead mason jar", badges: ["⭐ Superfood", "Prep-Ahead", "Vegan"] },
  { id: "sa4", category: "FRUIT BOWL", emoji: "🍈", title: "Golden Papaya Boat", desc: "Halved papaya vessel, blackberries, orange segments, ginger-lime drizzle, whipped coconut yogurt, edible flowers", badges: ["⭐ Superfood", "10 min", "GF"] },
  { id: "sa5", category: "FRUIT BOWL", emoji: "🫐", title: "Triple Berry Açaí Bowl", desc: "Açaí base, strawberry + blackberry + cranberry compote layers, pea protein, walnut oil drizzle, flax seeds", badges: ["⭐ Superfood", "15 min", "Vegan", "GF"] },
  { id: "sa6", category: "FRUIT BOWL", emoji: "🍊", title: "Citrus & Pomegranate Sunrise Bowl", desc: "Orange + lime segments, pomegranate jewels, papaya, cranberry compote drizzle, ACV, fresh mint, cinnamon", badges: ["⭐ Superfood", "10 min", "Vegan", "GF"] },
];

const dayConfig = {
  Monday:    { theme: "Warm Oat Bowls",         emoji: "🥣", cards: mondayCards,    color: "#8B5E1A", bg: "#F5EDD8" },
  Tuesday:   { theme: "Warm Broth Bowls",       emoji: "🍵", cards: tuesdayCards,   color: "#1A5A40", bg: "#E8F5F0" },
  Wednesday: { theme: "Hot Breakfast Scrambles",emoji: "🍳", cards: wednesdayCards, color: "#7A1040", bg: "#FDE8F0" },
  Thursday:  { theme: "Breakfast Toasts",       emoji: "🍞", cards: thursdayCards,  color: "#2A4A2A", bg: "#EAF0EA" },
  Friday:    { theme: "Breakfast Fruit Bowls",  emoji: "🍓", cards: fridayCards,    color: "#7A3A10", bg: "#FEF3E8" },
  Saturday:  { theme: "DIY Weekend",            emoji: "🌿", cards: weekendCards,   color: "#4A1A7A", bg: "#F0EAF8", diy: true },
  Sunday:    { theme: "DIY Weekend",            emoji: "🌿", cards: weekendCards,   color: "#4A1A7A", bg: "#F0EAF8", diy: true },
};

const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

const mealTabs = [
  { id: "breakfast",  label: "Breakfast",  icon: "☀️" },
  { id: "smoothies",  label: "Smoothies",  icon: "🥤" },
  { id: "snacks",     label: "Snacks",     icon: "🍎" },
  { id: "lunch",      label: "Lunch",      icon: "🌿" },
  { id: "dinner",     label: "Dinner",     icon: "🌙" },
];

function MenuCard({ card, isSelected, onToggle }) {
  const catStyle = categoryColors[card.category] || { bg: "#F5EDD8", text: "#8B5E1A" };
  return (
    <div onClick={onToggle} style={{
      background: "#fff",
      border: isSelected ? `2px solid ${BRAND.gold}` : `1px solid ${BRAND.border}`,
      borderRadius: 10,
      padding: "20px 20px 16px",
      cursor: "pointer",
      position: "relative",
      transition: "all 0.18s",
      boxShadow: isSelected ? "0 4px 18px rgba(201,168,76,0.18)" : "0 1px 4px rgba(0,0,0,0.04)",
    }}>
      <div style={{ position: "absolute", top: 14, right: 14, width: 20, height: 20, borderRadius: "50%", border: `1.5px solid ${isSelected ? BRAND.gold : "#CCC"}`, background: isSelected ? BRAND.gold : "transparent", display: "flex", alignItems: "center", justifyContent: "center" }}>
        {isSelected && <span style={{ color: "#fff", fontSize: 12, lineHeight: 1 }}>✓</span>}
      </div>
      <div style={{ fontSize: 32, marginBottom: 12 }}>{card.emoji}</div>
      <div style={{ display: "inline-block", background: catStyle.bg, color: catStyle.text, fontSize: 9, letterSpacing: 2, fontFamily: "sans-serif", textTransform: "uppercase", padding: "3px 8px", borderRadius: 2, marginBottom: 8, fontWeight: 600 }}>{card.category}</div>
      <div style={{ fontSize: 16, fontFamily: "Georgia, serif", color: BRAND.brown, lineHeight: 1.3, marginBottom: 8 }}>{card.title}</div>
      <div style={{ fontSize: 12, color: "#666", fontFamily: "sans-serif", lineHeight: 1.6, marginBottom: 14 }}>{card.desc}</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
        {card.badges.map(b => (
          <span key={b} style={{ fontSize: 10, fontFamily: "sans-serif", color: b.includes("⭐") ? BRAND.gold : BRAND.muted, letterSpacing: 0.5 }}>{b}</span>
        ))}
      </div>
    </div>
  );
}

export default function MenuDashboard() {
  const [activeDay, setActiveDay]   = useState("Monday");
  const [activeMeal, setActiveMeal] = useState("breakfast");
  const [selected, setSelected]     = useState({});

  const toggleSelect = (id) => setSelected(prev => ({ ...prev, [id]: !prev[id] }));

  const allCards = [...Object.values(dayConfig).flatMap(d => d.cards), ...snackCards, ...smoothieCards];
  const selectedCount  = Object.values(selected).filter(Boolean).length;
  const selectedTitles = allCards.filter(c => selected[c.id]).map(c => c.title);

  const cfg = dayConfig[activeDay];

  return (
    <div style={{ fontFamily: "Georgia, serif", background: BRAND.cream, minHeight: "100vh", color: BRAND.text }}>

      {/* Header */}
      <div style={{ background: BRAND.brown, padding: "28px 40px 24px", display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
        <div>
          <div style={{ color: BRAND.gold, fontSize: 22, letterSpacing: 1 }}>Ty's Savory Sweet Kitchen</div>
          <div style={{ color: "#C4A96A", fontSize: 11, letterSpacing: 3, marginTop: 4, fontFamily: "sans-serif", textTransform: "uppercase" }}>Private Chef · Los Angeles</div>
        </div>
        <div style={{ color: "#C4A96A", fontSize: 13, fontStyle: "italic", fontFamily: "sans-serif" }}>Week of May 18 – May 24</div>
      </div>

      <div style={{ maxWidth: 940, margin: "0 auto", padding: "40px 24px 60px" }}>

        {/* Title */}
        <div style={{ marginBottom: 32 }}>
          <div style={{ fontSize: 34, fontWeight: 400, lineHeight: 1.1, color: BRAND.brown }}>Your Weekly</div>
          <div style={{ fontSize: 34, fontStyle: "italic", color: BRAND.gold, lineHeight: 1.1 }}>Menu Selections</div>
          <p style={{ marginTop: 14, fontSize: 13, color: "#666", fontFamily: "sans-serif", lineHeight: 1.7, maxWidth: 520 }}>
            Choose your day, pick a meal category, then tap your favorites. Chef Ty receives your picks and prepares everything fresh.
          </p>
        </div>

        {/* Your Picks Bar */}
        <div style={{ borderTop: `1px solid ${BRAND.border}`, borderBottom: `1px solid ${BRAND.border}`, padding: "14px 0", display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 28 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, fontFamily: "sans-serif" }}>
            <span style={{ fontSize: 11, letterSpacing: 2, color: BRAND.muted, textTransform: "uppercase" }}>Your Picks</span>
            <span style={{ fontSize: 13, color: selectedCount > 0 ? BRAND.brown : BRAND.muted, fontStyle: selectedCount > 0 ? "normal" : "italic" }}>
              {selectedCount > 0 ? `${selectedCount} selected` : "No selections yet"}
            </span>
          </div>
          <button onClick={() => alert(selectedCount > 0 ? `Selections sent:\n${selectedTitles.join("\n")}` : "No selections yet.")}
            style={{ background: selectedCount > 0 ? BRAND.gold : "transparent", color: selectedCount > 0 ? BRAND.brown : BRAND.muted, border: `1px solid ${selectedCount > 0 ? BRAND.gold : BRAND.border}`, padding: "8px 18px", fontSize: 11, letterSpacing: 2, textTransform: "uppercase", cursor: "pointer", fontFamily: "sans-serif", borderRadius: 2, transition: "all 0.2s", fontWeight: 600 }}>
            Send Selections →
          </button>
        </div>

        {/* Day Tabs */}
        <div style={{ display: "flex", gap: 0, marginBottom: 28, borderBottom: `1px solid ${BRAND.border}`, overflowX: "auto" }}>
          {days.map(day => {
            const dc = dayConfig[day];
            const isActive = activeDay === day;
            return (
              <button key={day} onClick={() => setActiveDay(day)} style={{
                padding: "10px 16px", background: "none", border: "none",
                borderBottom: isActive ? `2px solid ${BRAND.gold}` : "2px solid transparent",
                color: isActive ? BRAND.brown : BRAND.muted,
                fontFamily: "Georgia, serif", fontSize: 14, cursor: "pointer",
                fontWeight: isActive ? 600 : 400, marginBottom: -1, whiteSpace: "nowrap",
                display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
              }}>
                <span>{day}</span>
                {isActive && <span style={{ fontSize: 9, letterSpacing: 1.5, fontFamily: "sans-serif", textTransform: "uppercase", color: dc.color, marginTop: 1 }}>{dc.emoji} {dc.theme}</span>}
              </button>
            );
          })}
        </div>

        {/* Meal Tabs */}
        <div style={{ display: "flex", gap: 0, marginBottom: 32, borderBottom: `1px solid ${BRAND.border}` }}>
          {mealTabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveMeal(tab.id)} style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "10px 22px", background: "none", border: "none",
              borderBottom: activeMeal === tab.id ? `2px solid ${BRAND.gold}` : "2px solid transparent",
              color: activeMeal === tab.id ? BRAND.brown : BRAND.muted,
              fontFamily: "sans-serif", fontSize: 11, letterSpacing: 2, textTransform: "uppercase",
              cursor: "pointer", marginBottom: -1,
            }}>
              <span style={{ fontSize: 14 }}>{tab.icon}</span> {tab.label}
            </button>
          ))}
        </div>

        {/* Breakfast Content */}
        {activeMeal === "breakfast" && (
          <>
            {/* Day theme pill */}
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: cfg.bg, padding: "8px 16px", borderRadius: 20, marginBottom: 20 }}>
              <span style={{ fontSize: 18 }}>{cfg.emoji}</span>
              <span style={{ fontSize: 11, letterSpacing: 2, fontFamily: "sans-serif", textTransform: "uppercase", color: cfg.color, fontWeight: 700 }}>{cfg.theme}</span>
            </div>

            {/* Weekend DIY notice */}
            {cfg.diy && (
              <div style={{ background: "#F0EAF8", border: "1px solid #D8C8F0", borderRadius: 8, padding: "14px 20px", marginBottom: 24, fontFamily: "sans-serif" }}>
                <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: 1.5, textTransform: "uppercase", color: "#4A1A7A", marginBottom: 4 }}>DIY Weekend</div>
                <div style={{ fontSize: 13, color: "#555", lineHeight: 1.6 }}>Chef Ty prepares your weekend selections ahead of time — ready to grab from the fridge. Choose your overnight oats and fruit bowls below.</div>
              </div>
            )}

            <div style={{ fontSize: 11, letterSpacing: 3, color: BRAND.muted, fontFamily: "sans-serif", textTransform: "uppercase", marginBottom: 24 }}>Morning Meals · Choose One</div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              {cfg.cards.map(card => (
                <MenuCard key={card.id} card={card} isSelected={!!selected[card.id]} onToggle={() => toggleSelect(card.id)} />
              ))}
            </div>
          </>
        )}

        {/* Smoothies Content */}
        {activeMeal === "smoothies" && (
          <>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#F0E8F8", padding: "8px 16px", borderRadius: 20, marginBottom: 20 }}>
              <span style={{ fontSize: 18 }}>🥤</span>
              <span style={{ fontSize: 11, letterSpacing: 2, fontFamily: "sans-serif", textTransform: "uppercase", color: "#5A1A7A", fontWeight: 700 }}>Midday Protein Smoothies</span>
            </div>
            <div style={{ background: "#F0E8F8", border: "1px solid #D8C8F0", borderRadius: 8, padding: "12px 18px", marginBottom: 24, fontFamily: "sans-serif" }}>
              <div style={{ fontSize: 12, color: "#5A1A7A", lineHeight: 1.7 }}>
                All smoothies are built on <strong>pea protein</strong> · Viome-aligned · no banana · no spinach · adaptogen powders: reishi, lion's mane, chaga, ashwagandha, maca · designed for midday nourishment and low-inflammatory living
              </div>
            </div>
            <div style={{ fontSize: 11, letterSpacing: 3, color: BRAND.muted, fontFamily: "sans-serif", textTransform: "uppercase", marginBottom: 24 }}>Choose Your Shake</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              {smoothieCards.map(card => (
                <MenuCard key={card.id} card={card} isSelected={!!selected[card.id]} onToggle={() => toggleSelect(card.id)} />
              ))}
            </div>
          </>
        )}

        {/* Snacks Content */}
        {activeMeal === "snacks" && (
          <>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#FEF3E8", padding: "8px 16px", borderRadius: 20, marginBottom: 20 }}>
              <span style={{ fontSize: 18 }}>🍎</span>
              <span style={{ fontSize: 11, letterSpacing: 2, fontFamily: "sans-serif", textTransform: "uppercase", color: "#7A3A10", fontWeight: 700 }}>Dips · Salsas · Marinated Cups</span>
            </div>
            <div style={{ background: "#F5EDD8", border: "1px solid #E8DDD0", borderRadius: 8, padding: "12px 18px", marginBottom: 24, fontFamily: "sans-serif" }}>
              <div style={{ fontSize: 12, color: "#8B5E1A", lineHeight: 1.6 }}>
                All dips are <strong>Viome-aligned</strong> · vegetarian · egg-free · served with crudité or house tortilla chips
              </div>
            </div>
            <div style={{ fontSize: 11, letterSpacing: 3, color: BRAND.muted, fontFamily: "sans-serif", textTransform: "uppercase", marginBottom: 24 }}>Snacks · Choose Your Favorites</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              {snackCards.map(card => (
                <MenuCard key={card.id} card={card} isSelected={!!selected[card.id]} onToggle={() => toggleSelect(card.id)} />
              ))}
            </div>
          </>
        )}

        {/* Other meal tabs placeholder */}
        {activeMeal !== "breakfast" && activeMeal !== "snacks" && activeMeal !== "smoothies" && (
          <div style={{ textAlign: "center", padding: "80px 0", color: BRAND.muted, fontFamily: "sans-serif" }}>
            <div style={{ fontSize: 32, marginBottom: 16 }}>{mealTabs.find(t => t.id === activeMeal)?.icon}</div>
            <div style={{ fontSize: 14, letterSpacing: 1 }}>{activeDay} {mealTabs.find(t => t.id === activeMeal)?.label} menu coming soon</div>
          </div>
        )}

      </div>
    </div>
  );
}
